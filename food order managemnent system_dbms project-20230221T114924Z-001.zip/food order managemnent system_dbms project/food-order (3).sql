-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 08, 2022 at 07:03 PM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `food-order`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(10) UNSIGNED NOT NULL,
  `full_name` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `full_name`, `username`, `password`) VALUES
(29, 'Likhita Paharsha', '20je0673', '0cc175b9c0f1b6a831c399e269772661'),
(30, 'Lakshmi Durga Devi', '20je0513', 'c81e728d9d4c2f636f067f89cc14862c'),
(31, 'Tata Dedeepya', '20je1023', 'eccbc87e4b5ce2fe28308fd9f2a7baf3'),
(32, 'Aditya Sinha', '19je0072', 'a87ff679a2f3e71d9181a67b7542122c');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(100) NOT NULL,
  `image_name` varchar(200) NOT NULL,
  `featured` varchar(10) NOT NULL,
  `active` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `title`, `image_name`, `featured`, `active`) VALUES
(7, 'Pizza', 'Food_Category_39.jpg', 'Yes', 'Yes'),
(11, 'Burger', 'Food_Category_310.jpg', 'Yes', 'Yes'),
(12, 'Deserts', 'Food_Category_866.jpg', 'Yes', 'Yes');

-- --------------------------------------------------------

--
-- Table structure for table `food`
--

CREATE TABLE `food` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(150) NOT NULL,
  `description` text NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `image_name` varchar(255) NOT NULL,
  `category_id` int(10) UNSIGNED NOT NULL,
  `featured` varchar(10) NOT NULL,
  `active` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `food`
--

INSERT INTO `food` (`id`, `title`, `description`, `price`, `image_name`, `category_id`, `featured`, `active`) VALUES
(2, 'Chocolate icecream', ' Chocolate ice-cream with our \r\nbittersweet Belgian Dark Chocolate flavor.\r\n', '75.00', 'Food-Name-171.jpeg', 12, 'Yes', 'Yes'),
(3, 'Chessy Moroccan pizza ', 'Cheesy pizza made with freshly peeled tomatoes and special herbs.', '290.00', 'Food-Name-674.jpg', 7, 'Yes', 'Yes'),
(4, 'Pancakes', 'Light and fluffy pancakes made with fresh and juicy selected strawberries.', '175.00', 'Food-Name-758.png', 12, 'Yes', 'Yes'),
(5, 'ISM special burger', 'Made with Italian Sauce and organic vegetables, garnished with fresh coriander.', '125.00', 'Food-Name-807.jpg', 11, 'Yes', 'Yes'),
(6, 'Virgin Mojito', 'Brimming with fresh mint, fresh lime juice, club soda and plenty of ice!', '115.00', 'Food-Name-267.jpg', 12, 'Yes', 'Yes'),
(7, 'Pani puri', ' Crispy fried puri stuffed with potato, onions, spices and flavoured water.', '50.00', 'Food-Name-103.jpg', 12, 'Yes', 'Yes'),
(8, 'Steamed momos', 'Momo are bite-size dumplings made with a spoonful of stuffing wrapped in dough.', '120.00', 'Food-Name-904.jpg', 7, 'Yes', 'No'),
(9, 'Doughnut', 'a popular comfort dessert that tastes absolutely divine, made from leavened fried dough', '80.00', 'Food-Name-4.jpg', 7, 'No', 'Yes'),
(10, 'biryani', 'hyderabadi chicken biryani it is', '250.00', 'Food-Name-51.jpg', 7, 'Yes', 'Yes');

-- --------------------------------------------------------

--
-- Table structure for table `order`
--

CREATE TABLE `order` (
  `food` varchar(150) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `qty` int(11) NOT NULL,
  `total` decimal(10,2) NOT NULL,
  `order_date` datetime NOT NULL,
  `status` varchar(30) NOT NULL,
  `customer_name` varchar(100) NOT NULL,
  `customer_contact` varchar(20) NOT NULL,
  `customer_email` varchar(100) NOT NULL,
  `customer_address` int(255) NOT NULL,
  `id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `food`
--
ALTER TABLE `food`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order`
--
ALTER TABLE `order`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `food`
--
ALTER TABLE `food`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `order`
--
ALTER TABLE `order`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
