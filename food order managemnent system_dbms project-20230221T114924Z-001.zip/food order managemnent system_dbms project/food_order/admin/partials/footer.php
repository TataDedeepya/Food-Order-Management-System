 <!--footer section starts here-->
 <div class=footer>
            <div class=wrapper>
            <p class=text-center>Hakuna Matata</p>
            </div>
        </div>
        <!--footer section ends here-->

    </body>
</html>