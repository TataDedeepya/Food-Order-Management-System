<!-- footer Section Starts Here -->
<section class="footer">
        <div style="background-color: black;">
        <div class="container text-center">
            <p style="color: white;">Designed By <a href="#">Likhita | Devi | Dedeepya | Aditya </a></p>
        </div>
    </div>
    </section>
    <!-- footer Section Ends Here -->

</body>
</html>